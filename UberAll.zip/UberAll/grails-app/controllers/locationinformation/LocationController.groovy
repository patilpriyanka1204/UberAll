package locationinformation

import grails.converters.*
import org.h2.tools.Csv
import org.springframework.http.*
import org.springframework.web.client.RestTemplate
import groovy.json.JsonSlurper

class LocationController {

    List<Location> li;

    def index() {

        String base = "https://sandbox.uberall.com/api/locations?max=100"
        String apiString = base

        HttpHeaders headers = new HttpHeaders();
        headers.set("privateKey", "aGQZ9qMJmh2QOWGmuNw0RhZvPcN4Lmt4FUFdIc4ltf6d0Bopeq2IuhyGB3ihr1P9");

        RestTemplate res = new RestTemplate();
        HttpEntity<Void> requestEntity = new HttpEntity<>(headers);

        ResponseObject response = new JsonSlurper().parseText(res.exchange(
                base, HttpMethod.GET, requestEntity, String.class).getBody())

         li = response.getResponse().getLocations()
        List<Location> str = new ArrayList<Location>();
        for(Location i : li){
            str.add(i)
        }

        withFormat{
            html locationsList:str
            xml{render str as XML}
            csv{render str as Csv }
            json{render str as JSON}

        }

    }


}
