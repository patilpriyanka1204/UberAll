package locationinformation

class ReponseInfo {

    String offset
    String max
    String count
    List<Location> locations;

    String getOffset() {
        return offset
    }

    void setOffset(String offset) {
        this.offset = offset
    }

    String getMax() {
        return max
    }

    void setMax(String max) {
        this.max = max
    }

    String getCount() {
        return count
    }

    void setCount(String count) {
        this.count = count
    }

    List<Location> getLocations() {
        return locations
    }

    void setLocations(List<Location> loc) {
        this.locations = loc
    }
    static constraints = {
    }
}
