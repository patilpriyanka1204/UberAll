package locationinformation

class OpeningHours {


    int dayOfWeek
    String from1
    String to1


    int getDayOfWeek() {
        return dayOfWeek
    }

    void setDayOfWeek(int dayOfWeek) {
        this.dayOfWeek = dayOfWeek
    }

    String getFrom1() {
        return from1
    }

    void setFrom1(String from1) {
        this.from1 = from1
    }

    String getTo1() {
        return to1
    }

    void setTo1(String to1) {
        this.to1 = to1
    }

    static constraints = {
    }
}
