package locationinformation

class ResponseObject {
    String status
    ReponseInfo response

    String getStatus() {
        return status
    }

    void setStatus(String status) {
        this.status = status
    }

    ReponseInfo getResponse() {
        return response
    }

    void setResponse(ReponseInfo response) {
        this.response = response
    }
    static constraints = {
    }
}
