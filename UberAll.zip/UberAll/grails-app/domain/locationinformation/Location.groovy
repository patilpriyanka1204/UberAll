package locationinformation

import grails.rest.*
import org.grails.web.json.JSONObject

@Resource(uri = '/locations' ,formats = ['json','xml'])
class Location {
    String name;
    String city;
    String zip;
    String streetAndStreetNo

    List<OpeningHours> getOpeningHours() {
        return openingHours
    }
    List<OpeningHours> openingHours;

    void setOpeningHours(List<OpeningHours> openingHours) {
        this.openingHours = openingHours
    }
    List<String> keywords
    Float lat
    Float lng

    String getName() {
        return name
    }

    void setName(String name) {
        this.name = name
    }

    String getCity() {
        return city
    }

    void setCity(String city) {
        this.city = city
    }

    String getZip() {
        return zip
    }

    void setZip(String zip) {
        this.zip = zip
    }

    String getStreetAndStreetNo() {
        return streetAndStreetNo
    }

    void setStreetAndStreetNo(String streetAndStreetNo) {
        this.streetAndStreetNo = streetAndStreetNo
    }


    List<String> getKeywords() {
        return keywords
    }

    void setKeywords(List<String> keywords) {
        this.keywords = keywords
    }

    Float getLat() {
        return lat
    }

    void setLat(Float lat) {
        this.lat = lat
    }

    Float getLng() {
        return lng
    }

    void setLng(Float lng) {
        this.lng = lng
    }
    static constraints = {
    }
}
