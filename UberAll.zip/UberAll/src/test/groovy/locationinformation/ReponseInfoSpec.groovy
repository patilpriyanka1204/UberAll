package locationinformation

import grails.testing.gorm.DomainUnitTest
import spock.lang.Specification

class ReponseInfoSpec extends Specification implements DomainUnitTest<ReponseInfo> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
