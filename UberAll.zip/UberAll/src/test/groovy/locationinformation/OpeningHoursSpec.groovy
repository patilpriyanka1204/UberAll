package locationinformation

import grails.testing.gorm.DomainUnitTest
import spock.lang.Specification

class OpeningHoursSpec extends Specification implements DomainUnitTest<OpeningHours> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
