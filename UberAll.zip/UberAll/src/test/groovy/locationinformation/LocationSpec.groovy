package locationinformation

import grails.testing.gorm.DomainUnitTest
import spock.lang.Specification

class LocationSpec extends Specification implements DomainUnitTest<Location> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
