package locationinformation

import grails.testing.web.controllers.ControllerUnitTest
import spock.lang.Specification

class LocationControllerSpec extends Specification implements ControllerUnitTest<LocationController> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
